#!/bin/bash

args=$@
is_sh_ver=v1.33

. /etc/xray/sh/src/init.sh